#[derive(Debug, Clone)]
pub struct OverlaySource {
    pub enabled: bool,
    pub name: String,
    pub x_percent: f32,
    pub y_percent: f32,
    pub width_percent: f32,
    pub bounce: bool,
}

impl Default for OverlaySource {
    fn default() -> Self {
        Self {
            enabled: false,
            name: "跳ねるししゃも（テスト）".to_owned(),
            x_percent: 78.0,
            y_percent: 70.0,
            width_percent: 16.0,
            bounce: true,
        }
    }
}

impl OverlaySource {
    pub fn compose_test_overlay(&self, rgba: &mut [u8], width: u32, height: u32, time_seconds: f32) {
        if !self.enabled || width == 0 || height == 0 {
            return;
        }
        let expected = width as usize * height as usize * 4;
        if rgba.len() < expected {
            return;
        }

        let fish_w = ((width as f32 * (self.width_percent / 100.0)).round() as i32).max(24);
        let fish_h = (fish_w as f32 * 0.42).round() as i32;
        let bounce = if self.bounce {
            (time_seconds * 4.2).sin().abs() * height as f32 * 0.055
        } else {
            0.0
        };
        let cx = (width as f32 * (self.x_percent / 100.0)).round() as i32;
        let cy = (height as f32 * (self.y_percent / 100.0) - bounce).round() as i32;

        // A tiny procedural fish-shaped test wipe. This intentionally does not
        // depend on an external image/model, so the compositor can be tested first.
        let body_rx = fish_w / 2;
        let body_ry = fish_h / 2;
        for yy in -body_ry..=body_ry {
            for xx in -body_rx..=body_rx {
                let nx = xx as f32 / body_rx.max(1) as f32;
                let ny = yy as f32 / body_ry.max(1) as f32;
                if nx * nx + ny * ny <= 1.0 {
                    blend_pixel(rgba, width, height, cx + xx, cy + yy, [232, 150, 76, 235]);
                }
            }
        }

        // Tail triangle.
        let tail_x = cx - body_rx;
        for dx in 0..(fish_w / 3).max(1) {
            let half = ((fish_h as f32 * 0.65) * (1.0 - dx as f32 / (fish_w / 3).max(1) as f32)) as i32;
            for dy in -half..=half {
                blend_pixel(rgba, width, height, tail_x - dx, cy + dy, [220, 126, 63, 225]);
            }
        }

        // Eye.
        let eye_x = cx + body_rx / 2;
        let eye_y = cy - body_ry / 4;
        let eye_r = (fish_h / 10).max(2);
        for yy in -eye_r..=eye_r {
            for xx in -eye_r..=eye_r {
                if xx * xx + yy * yy <= eye_r * eye_r {
                    blend_pixel(rgba, width, height, eye_x + xx, eye_y + yy, [25, 25, 25, 255]);
                }
            }
        }
    }
}

fn blend_pixel(rgba: &mut [u8], width: u32, height: u32, x: i32, y: i32, src: [u8; 4]) {
    if x < 0 || y < 0 || x >= width as i32 || y >= height as i32 {
        return;
    }
    let idx = ((y as u32 * width + x as u32) * 4) as usize;
    let alpha = src[3] as f32 / 255.0;
    let inv = 1.0 - alpha;
    rgba[idx] = (src[0] as f32 * alpha + rgba[idx] as f32 * inv).round() as u8;
    rgba[idx + 1] = (src[1] as f32 * alpha + rgba[idx + 1] as f32 * inv).round() as u8;
    rgba[idx + 2] = (src[2] as f32 * alpha + rgba[idx + 2] as f32 * inv).round() as u8;
    rgba[idx + 3] = 255;
}
