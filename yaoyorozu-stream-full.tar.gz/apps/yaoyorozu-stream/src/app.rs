use crate::view_model::StreamViewModel;
use crate::streaming::{StreamingPlatform, StreamingSession, StreamingTargetConfig};
use crate::scene::OverlaySource;
use crate::ui_layout::{
    compact_source_name, normal_preview_size, AUDIO_METER_HEIGHT, AUDIO_METER_WIDTH,
    METER_GREEN_END_DB, METER_ORANGE_END_DB, METER_YELLOW_END_DB,
    SCENE_LABELS, SOURCE_SELECTOR_WIDTH,
};
use eframe::egui;
use std::{fs, path::PathBuf, sync::mpsc};
use stream_capture::{enumerate_windows, CaptureSource, CaptureWorker, PreviewMode, WindowInfo};
use stream_audio::{
    application_source_label, dbfs, selection_label, AudioChannelKind, AudioDeviceSelection,
    AudioWorker, ChannelMixerControl, MixerControl,
};
use stream_recording::{ffmpeg_location_string, EncoderPreference, RecordingConfig, RecordingPaths, RecordingSession};
use stream_core::{MarkerKind, StreamPreset};

pub fn fit_aspect(
    source_w: f32,
    source_h: f32,
    available_w: f32,
    available_h: f32,
) -> (f32, f32) {
    if source_w <= 0.0 || source_h <= 0.0 || available_w <= 0.0 || available_h <= 0.0 {
        return (0.0, 0.0);
    }
    let scale = (available_w / source_w).min(available_h / source_h);
    (source_w * scale, source_h * scale)
}

fn paint_audio_meter(ui: &mut egui::Ui, level: f32) -> egui::Response {
    let (rect, response) = ui.allocate_exact_size(
        egui::vec2(AUDIO_METER_WIDTH, AUDIO_METER_HEIGHT),
        egui::Sense::hover(),
    );

    let painter = ui.painter();
    painter.rect_filled(rect, 2.0, egui::Color32::from_rgb(35, 38, 43));

    let db = dbfs(level).clamp(-60.0, 0.0);
    let filled = ((db + 60.0) / 60.0).clamp(0.0, 1.0);

    let green_end = ((METER_GREEN_END_DB + 60.0) / 60.0).clamp(0.0, 1.0);
    let yellow_end = ((METER_YELLOW_END_DB + 60.0) / 60.0).clamp(0.0, 1.0);
    let orange_end = ((METER_ORANGE_END_DB + 60.0) / 60.0).clamp(0.0, 1.0);

    let segments = [
        (0.0, green_end, egui::Color32::from_rgb(55, 190, 95)),
        (green_end, yellow_end, egui::Color32::from_rgb(230, 205, 65)),
        (yellow_end, orange_end, egui::Color32::from_rgb(235, 145, 50)),
        (orange_end, 1.0, egui::Color32::from_rgb(220, 65, 65)),
    ];

    for (start, end, color) in segments {
        let visible_end = filled.min(end);
        if visible_end <= start {
            continue;
        }

        let left = egui::lerp(rect.left()..=rect.right(), start);
        let right = egui::lerp(rect.left()..=rect.right(), visible_end);
        let part = egui::Rect::from_min_max(
            egui::pos2(left, rect.top()),
            egui::pos2(right, rect.bottom()),
        );
        painter.rect_filled(part, 1.0, color);
    }

    response.on_hover_text(format!("{:.1} dBFS", db))
}

fn apply_accessible_ui_style(ctx: &egui::Context) {
    let mut style = (*ctx.style()).clone();
    style.text_styles.insert(egui::TextStyle::Small, egui::FontId::proportional(14.0));
    style.text_styles.insert(egui::TextStyle::Body, egui::FontId::proportional(15.0));
    style.text_styles.insert(egui::TextStyle::Button, egui::FontId::proportional(15.0));
    style.text_styles.insert(egui::TextStyle::Monospace, egui::FontId::monospace(14.0));
    style.text_styles.insert(egui::TextStyle::Heading, egui::FontId::proportional(19.0));
    style.spacing.button_padding = egui::vec2(8.0, 6.0);
    style.spacing.interact_size.y = 28.0;
    style.spacing.item_spacing = egui::vec2(8.0, 6.0);
    ctx.set_style(style);
}

fn install_windows_japanese_font(ctx: &egui::Context) -> Option<PathBuf> {
    let windir = std::env::var_os("WINDIR")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from(r"C:\Windows"));

    let candidates = ["YuGothM.ttc", "YuGothR.ttc", "meiryo.ttc", "msgothic.ttc"];

    for name in candidates {
        let path = windir.join("Fonts").join(name);
        let Ok(bytes) = fs::read(&path) else {
            continue;
        };

        let mut fonts = egui::FontDefinitions::default();
        fonts.font_data.insert(
            "yaoyorozu_jp".to_owned(),
            egui::FontData::from_owned(bytes).into(),
        );

        for family in [egui::FontFamily::Proportional, egui::FontFamily::Monospace] {
            fonts
                .families
                .entry(family)
                .or_default()
                .insert(0, "yaoyorozu_jp".to_owned());
        }

        ctx.set_fonts(fonts);
        return Some(path);
    }

    None
}

pub struct YaoyorozuApp {
    vm: StreamViewModel,
    elapsed_ms: u64,
    stream_title: String,

    windows: Vec<WindowInfo>,
    selected_source: CaptureSource,
    capture: Option<CaptureWorker>,
    capture_target_fps: u32,

    preview_texture: Option<egui::TextureHandle>,
    preview_size: [u32; 2],

    capture_message: String,
    font_message: String,
    audio: Option<AudioWorker>,
    audio_message: String,
    selected_application_audio_pid: Option<u32>,
    application_audio_message: String,
    recording: Option<RecordingSession>,
    finalize_rx: Option<mpsc::Receiver<Result<RecordingPaths, stream_recording::RecordingError>>>,
    recording_message: String,
    ffmpeg_location: String,
    encoder_preference: EncoderPreference,
    recording_preview_mode: PreviewMode,
    streaming_target: StreamingTargetConfig,
    show_stream_key: bool,
    overlay_source: OverlaySource,
    app_started_at: std::time::Instant,
    streaming: Option<StreamingSession>,
    streaming_message: String,
}

impl YaoyorozuApp {
    pub fn new(cc: &eframe::CreationContext<'_>) -> Self {
        apply_accessible_ui_style(&cc.egui_ctx);
        let font_message = match install_windows_japanese_font(&cc.egui_ctx) {
            Some(path) => format!("日本語フォント: {}", path.display()),
            None => "Windows日本語フォントが見つかりません".to_owned(),
        };

        let windows = enumerate_windows().unwrap_or_default();
        let selected_source = CaptureSource::Desktop;
        let capture_target_fps = StreamPreset::Game.dimensions().2;

        let (capture, capture_message) =
            match CaptureWorker::start(selected_source.clone(), capture_target_fps) {
                Ok(worker) => (
                    Some(worker),
                    format!("WGC: デスクトップ全体 / target {capture_target_fps} FPS"),
                ),
                Err(err) => (None, format!("キャプチャ開始失敗: {err}")),
            };

        let (audio, audio_message) = match AudioWorker::start_default_devices() {
            Ok(worker) => (Some(worker), "WASAPI音声メーター: 稼働中".to_owned()),
            Err(err) => (None, format!("音声開始失敗: {err}")),
        };

        Self {
            vm: StreamViewModel::default(),
            elapsed_ms: 0,
            stream_title: "Yaoyorozu Stream".to_owned(),
            windows,
            selected_source,
            capture,
            capture_target_fps,
            preview_texture: None,
            preview_size: [0, 0],
            capture_message,
            font_message,
            audio,
            audio_message,
            selected_application_audio_pid: None,
            application_audio_message: "アプリ音声: 一覧から選択してください".to_owned(),
            recording: None,
            finalize_rx: None,
            recording_message: "録画: 待機中".to_owned(),
            ffmpeg_location: ffmpeg_location_string(),
            encoder_preference: EncoderPreference::Amf,
            recording_preview_mode: PreviewMode::Fps15,
            streaming_target: StreamingTargetConfig::default(),
            show_stream_key: false,
            overlay_source: OverlaySource::default(),
            app_started_at: std::time::Instant::now(),
            streaming: None,
            streaming_message: "配信: 待機中".to_owned(),
        }
    }

    fn set_stream_preset(&mut self, preset: StreamPreset) {
        let new_fps = preset.dimensions().2;
        self.vm.set_preset(preset);

        if new_fps != self.capture_target_fps
            && self.recording.is_none()
            && self.finalize_rx.is_none()
        {
            self.capture_target_fps = new_fps;
            let source = self.selected_source.clone();
            self.switch_source(source);
        }
    }

    fn refresh_windows(&mut self) {
        match enumerate_windows() {
            Ok(windows) => {
                self.windows = windows;
                self.capture_message =
                    format!("ウィンドウ一覧を更新: {} 件", self.windows.len());
            }
            Err(err) => {
                self.capture_message = format!("ウィンドウ一覧取得失敗: {err}");
            }
        }
    }

    fn switch_source(&mut self, source: CaptureSource) {
        let name = source.display_name().to_owned();

        // Drop previous worker first. Worker owns its capture thread and joins
        // during Drop, keeping capture lifetime localized.
        self.capture = None;
        self.preview_texture = None;
        self.preview_size = [0, 0];

        match CaptureWorker::start(source.clone(), self.capture_target_fps) {
            Ok(worker) => {
                self.selected_source = source;
                self.capture = Some(worker);
                self.capture_message =
                    format!("WGC: {name} / target {} FPS", self.capture_target_fps);
            }
            Err(err) => {
                self.capture_message = format!("キャプチャ切替失敗: {err}");
            }
        }
    }

    fn update_preview_texture(&mut self, ctx: &egui::Context) {
        let Some(capture) = &self.capture else {
            return;
        };

        let mut newest = None;
        while let Ok(frame) = capture.try_recv() {
            newest = Some(frame);
        }

        let Some(frame) = newest else {
            return;
        };

        self.preview_size = [frame.width, frame.height];
        let mut composed_rgba = frame.rgba.to_vec();
        self.overlay_source.compose_test_overlay(
            &mut composed_rgba,
            frame.width,
            frame.height,
            self.app_started_at.elapsed().as_secs_f32(),
        );
        let composed_frame = stream_capture::CaptureFrame {
            sequence: frame.sequence,
            width: frame.width,
            height: frame.height,
            rgba: std::sync::Arc::<[u8]>::from(composed_rgba),
        };
        if let Some(streaming) = &self.streaming {
            streaming.push_video_frame(&composed_frame);
        }
        let image = egui::ColorImage::from_rgba_unmultiplied(
            [composed_frame.width as usize, composed_frame.height as usize],
            &composed_frame.rgba,
        );

        if let Some(texture) = &mut self.preview_texture {
            texture.set(image, egui::TextureOptions::LINEAR);
        } else {
            self.preview_texture = Some(ctx.load_texture(
                "capture-preview",
                image,
                egui::TextureOptions::LINEAR,
            ));
        }
    }


    fn start_recording(&mut self) {
        if self.recording.is_some() || self.finalize_rx.is_some() {
            return;
        }

        let (out_w, out_h, fps) = self.vm.session.preset.dimensions();

        let config = RecordingConfig {
            source_width: self.preview_size[0],
            source_height: self.preview_size[1],
            output_width: out_w,
            output_height: out_h,
            fps,
            bitrate_kbps: 6000,
            encoder_preference: self.encoder_preference,
        };

        let Some(capture) = &self.capture else {
            self.recording_message = "録画開始失敗: キャプチャがありません".to_owned();
            return;
        };
        let gpu = capture.gpu_recording_handle();
        let _ = gpu.set_preview_mode(self.recording_preview_mode);

        let mixer = self
            .audio
            .as_ref()
            .map(|audio| audio.mixer_control())
            .unwrap_or_else(MixerControl::default);

        let audio_devices = self
            .audio
            .as_ref()
            .map(|audio| audio.device_state())
            .unwrap_or_default();

        let channel_mixer = self
            .audio
            .as_ref()
            .map(|audio| audio.channel_mixer())
            .unwrap_or_default();

        match RecordingSession::start_with_audio_routing(
            "recordings",
            config,
            gpu,
            mixer,
            channel_mixer,
            audio_devices,
        ) {
            Ok(session) => {
                self.recording_message = format!(
                    "録画中: {} / {}",
                    session.backend_name,
                    session.paths.root.display()
                );
                self.recording = Some(session);
            }
            Err(err) => {
                self.recording_message = format!("録画開始失敗: {err}");
            }
        }
    }

    fn stop_recording(&mut self) {
        let Some(session) = self.recording.take() else {
            return;
        };

        let mut manifest = stream_core::EditManifest::new(self.vm.session.clone());
        manifest.markers = self.vm.markers.clone();

        self.recording_message = "録画停止処理中… MP4を仕上げています".to_owned();
        self.finalize_rx = Some(session.stop_async(manifest));
    }

    fn poll_recording_finalize(&mut self) {
        let Some(rx) = &self.finalize_rx else {
            return;
        };

        match rx.try_recv() {
            Ok(Ok(paths)) => {
                self.recording_message =
                    format!("録画完了: {}", paths.final_video.display());
                if let Some(capture) = &self.capture {
                    let _ = capture
                        .gpu_recording_handle()
                        .set_preview_mode(PreviewMode::Fps30);
                }
                self.finalize_rx = None;
            }
            Ok(Err(err)) => {
                self.recording_message = format!("録画終了エラー: {err}");
                if let Some(capture) = &self.capture {
                    let _ = capture
                        .gpu_recording_handle()
                        .set_preview_mode(PreviewMode::Fps30);
                }
                self.finalize_rx = None;
            }
            Err(mpsc::TryRecvError::Empty) => {}
            Err(mpsc::TryRecvError::Disconnected) => {
                self.recording_message = "録画終了処理が予期せず終了しました".to_owned();
                if let Some(capture) = &self.capture {
                    let _ = capture
                        .gpu_recording_handle()
                        .set_preview_mode(PreviewMode::Fps30);
                }
                self.finalize_rx = None;
            }
        }
    }

    fn start_streaming(&mut self) {
        if self.streaming.is_some() {
            return;
        }
        let (w, h, fps) = self.vm.session.preset.dimensions();
        let live_audio = match self.audio.as_ref() {
            Some(audio) => match audio.start_live_audio_bridge() {
                Ok(bridge) => Some(bridge),
                Err(err) => {
                    self.streaming_message = format!("ライブ音声開始失敗: {err}");
                    return;
                }
            },
            None => None,
        };
        let live_audio_count = live_audio.as_ref().map(|bridge| bridge.inputs.len()).unwrap_or(0);
        match StreamingSession::start(
            &self.streaming_target,
            self.preview_size[0],
            self.preview_size[1],
            w,
            h,
            fps,
            live_audio,
        ) {
            Ok(session) => {
                self.streaming_message = format!(
                    "送信中: {} / {}×{} {} FPS / 映像: {} / ライブ音声 {}ch（受信確認は配信サービス側）",
                    session.platform().label(),
                    w,
                    h,
                    fps,
                    self.selected_source.display_name(),
                    live_audio_count
                );
                self.streaming = Some(session);
                self.vm.is_live = true;
            }
            Err(err) => {
                self.streaming_message = format!("配信開始失敗: {err}");
                self.vm.is_live = false;
            }
        }
    }

    fn stop_streaming(&mut self) {
        if let Some(session) = self.streaming.take() {
            session.stop();
        }
        self.streaming_message = "配信: 停止しました".to_owned();
        self.vm.is_live = false;
    }

    fn poll_streaming(&mut self) {
        let Some(streaming) = &mut self.streaming else {
            return;
        };
        match streaming.try_exit() {
            Ok(Some(status)) => {
                let diagnostic = streaming.diagnostic_summary();
                self.streaming_message = format!(
                    "配信プロセス終了: {status} / FFmpeg: {diagnostic}"
                );
                self.streaming = None;
                self.vm.is_live = false;
            }
            Ok(None) => {}
            Err(err) => {
                self.streaming_message = format!("配信状態確認失敗: {err}");
                self.streaming = None;
                self.vm.is_live = false;
            }
        }
    }

    fn source_selector(&mut self, ui: &mut egui::Ui) {
        ui.horizontal(|ui| {
            ui.label("キャプチャ対象");
            if self.recording.is_none()
                && self.finalize_rx.is_none()
                && ui.button("一覧更新").clicked()
            {
                self.refresh_windows();
            }
        });

        let selected_name = self.selected_source.display_name().to_owned();

        // フルのウィンドウ名は固定幅の折り返し領域へ表示する。
        // タイトル文字数でSidePanel自体が広がらないようにする。
        ui.scope(|ui| {
            ui.set_min_width(SOURCE_SELECTOR_WIDTH);
            ui.set_max_width(SOURCE_SELECTOR_WIDTH);
            ui.add(
                egui::Label::new(
                    egui::RichText::new(&selected_name)
                        .small()
                        .color(egui::Color32::LIGHT_GRAY),
                )
                .wrap(),
            );
        });

        if self.recording.is_some() || self.finalize_rx.is_some() || self.streaming.is_some() {
            ui.small(if self.streaming.is_some() {
                "配信中はソース切替を固定しています"
            } else {
                "録画中はソース切替を固定しています"
            });
            return;
        }

        let compact_selected = compact_source_name(&selected_name, 28);
        let mut requested: Option<CaptureSource> = None;

        egui::ComboBox::from_id_salt("capture-source")
            .selected_text(compact_selected)
            .width(SOURCE_SELECTOR_WIDTH)
            .show_ui(ui, |ui| {
                ui.set_min_width(SOURCE_SELECTOR_WIDTH);
                ui.set_max_width(SOURCE_SELECTOR_WIDTH);

                if ui
                    .selectable_label(
                        matches!(self.selected_source, CaptureSource::Desktop),
                        "デスクトップ全体",
                    )
                    .clicked()
                {
                    requested = Some(CaptureSource::Desktop);
                }

                ui.separator();

                for window in &self.windows {
                    let selected = match &self.selected_source {
                        CaptureSource::Window(current) => current.hwnd == window.hwnd,
                        CaptureSource::Desktop => false,
                    };

                    let compact_title = compact_source_name(&window.title, 36);
                    let response = ui.selectable_label(selected, compact_title);
                    if response.hovered() {
                        response.clone().on_hover_text(&window.title);
                    }
                    if response.clicked() {
                        requested = Some(CaptureSource::Window(window.clone()));
                    }
                }
            });

        if let Some(source) = requested {
            if source != self.selected_source {
                self.switch_source(source);
            }
        }
    }

    fn capture_source_panel(&mut self, ui: &mut egui::Ui) {
        ui.heading("映像ソース");
        self.source_selector(ui);
        ui.small(&self.capture_message);

        egui::CollapsingHeader::new("詳細情報")
            .id_salt("capture_details")
            .default_open(false)
            .show(ui, |ui| {
                if let Some(capture) = &self.capture {
                    let stats = capture.stats();
                    ui.small(format!("WGC callback: {:.1} FPS / frames {}", stats.measured_fps, stats.received_frames));
                    ui.small(format!("540p async readback: avg {:.2} ms / max {:.2} ms", stats.gpu_to_cpu_ms_avg, stats.gpu_to_cpu_ms_max));
                    ui.small(format!("Preview worker frames: {} / jobs dropped: {}", stats.preview_worker_frames, stats.preview_jobs_dropped));
                }
                ui.separator();
                ui.small(format!("FFmpeg: {}", self.ffmpeg_location));
                ui.small("録画Encoder: DirectX GPU / Windows Media Foundation H.264");
                ui.small("配信Encoder: FFmpeg h264_mf / RTMP・RTMPS");

                if self.recording.is_none() && self.finalize_rx.is_none() {
                    ui.horizontal(|ui| {
                        ui.label("録画中プレビュー");
                        egui::ComboBox::from_id_salt("recording-preview-mode")
                            .selected_text(match self.recording_preview_mode {
                                PreviewMode::Fps30 => "30 FPS",
                                PreviewMode::Fps15 => "15 FPS",
                                PreviewMode::Off => "OFF",
                            })
                            .show_ui(ui, |ui| {
                                ui.selectable_value(&mut self.recording_preview_mode, PreviewMode::Fps15, "15 FPS（推奨）");
                                ui.selectable_value(&mut self.recording_preview_mode, PreviewMode::Off, "OFF（最軽量）");
                                ui.selectable_value(&mut self.recording_preview_mode, PreviewMode::Fps30, "30 FPS");
                            });
                    });
                }

                if let Some(recording) = &self.recording {
                    ui.small(format!("GPU encoded frames: {} / status: {:?}", recording.encoded_frames(), recording.gpu_status()));
                }
            });
    }
}

impl eframe::App for YaoyorozuApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        self.poll_recording_finalize();
        self.poll_streaming();
        self.update_preview_texture(ctx);

        egui::TopBottomPanel::bottom("post_recording_controls").show(ctx, |ui| {
            ui.horizontal_wrapped(|ui| {
                ui.strong("録画後");
                ui.separator();
                if self.vm.can_send_to_aviutl2() {
                    let _ = ui.button("AviUtl2へ送る");
                } else {
                    ui.add_enabled(false, egui::Button::new("AviUtl2へ送る"));
                }

                ui.separator();
                for (label, kind) in [
                    ("CUT", MarkerKind::Cut),
                    ("SHORT", MarkerKind::Short),
                    ("CHAPTER", MarkerKind::Chapter),
                    ("NOTE", MarkerKind::Note),
                ] {
                    if ui.button(label).clicked() {
                        self.vm.add_marker(self.elapsed_ms, kind, label);
                    }
                }
                ui.label(format!("Markers: {}", self.vm.markers.len()));
                ui.separator();
                ui.small(&self.recording_message);

                // Phase 9.3.1.8: 上部ステータスバーを下部の空き領域へ統合。
                // プレビュー・映像ソース・音声ミキサーが使える縦領域を増やす。
                ui.separator();
                ui.strong("Yaoyorozu Stream");
                ui.separator();
                ui.label(self.streaming_target.connection_label());
                ui.separator();
                ui.label(if self.streaming.is_some() { "● 送信中" } else { "○ OFFLINE" });
            });
        });

        egui::TopBottomPanel::bottom("phase9_scene_panel")
            .exact_height(120.0)
            .show(ctx, |ui| {
                ui.heading("シーン");
                ui.horizontal_wrapped(|ui| {
                    for scene in SCENE_LABELS {
                        ui.selectable_label(scene == "ゲーム", scene);
                    }
                });
                ui.small("追加・保存は Phase 9.4");
            });

        egui::SidePanel::right("phase9_settings")
            .default_width(350.0)
            .resizable(true)
            .show(ctx, |ui| {
                egui::ScrollArea::vertical()
                    .id_salt("phase9_settings_scroll")
                    .auto_shrink([false, false])
                    .show(ui, |ui| {
                ui.heading("配信・録画設定");
                ui.label("配信タイトル");
                ui.text_edit_singleline(&mut self.stream_title);

                ui.separator();
                ui.heading("配信先");
                let mut selected_platform = self.streaming_target.platform;
                egui::ComboBox::from_id_salt("streaming-platform")
                    .selected_text(selected_platform.label())
                    .width(SOURCE_SELECTOR_WIDTH)
                    .show_ui(ui, |ui| {
                        for platform in StreamingPlatform::ALL {
                            ui.selectable_value(
                                &mut selected_platform,
                                platform,
                                platform.label(),
                            );
                        }
                    });
                if selected_platform != self.streaming_target.platform {
                    self.streaming_target.set_platform(selected_platform);
                    self.show_stream_key = false;
                    self.streaming_message = format!(
                        "配信先を{}へ切り替えました。URLとキーを設定してください",
                        selected_platform.label()
                    );
                }

                ui.label("サーバーURL");
                ui.add(
                    egui::TextEdit::singleline(&mut self.streaming_target.server_url)
                        .desired_width(SOURCE_SELECTOR_WIDTH)
                        .hint_text(self.streaming_target.platform.server_hint()),
                );

                ui.horizontal(|ui| {
                    ui.label("ストリームキー");
                    ui.checkbox(&mut self.show_stream_key, "表示");
                });
                let mut key_edit = egui::TextEdit::singleline(&mut self.streaming_target.stream_key)
                    .desired_width(SOURCE_SELECTOR_WIDTH)
                    .hint_text("配信サービスから取得したキー");
                if !self.show_stream_key {
                    key_edit = key_edit.password(true);
                }
                ui.add(key_edit);

                ui.horizontal(|ui| {
                    ui.label("映像bitrate");
                    ui.add(
                        egui::DragValue::new(&mut self.streaming_target.video_bitrate_kbps)
                            .range(500..=50_000)
                            .speed(100.0)
                            .suffix(" kbps"),
                    );
                });
                if self.streaming_target.is_ready() {
                    ui.small("配信先設定: 準備OK");
                } else {
                    ui.small(self.streaming_target.readiness_message());
                }

                ui.label("プリセット");
                ui.horizontal_wrapped(|ui| {
                    if ui.button("ゲーム 1080p60").clicked() {
                        self.set_stream_preset(StreamPreset::Game);
                    }
                    if ui.button("作業 1080p30").clicked() {
                        self.set_stream_preset(StreamPreset::Work);
                    }
                    if ui.button("軽量 720p30").clicked() {
                        self.set_stream_preset(StreamPreset::Light);
                    }
                });

                let (w, h, fps) = self.vm.session.preset.dimensions();
                ui.label(format!("録画出力: {w} × {h} / {fps} FPS"));
                ui.small("※ 300pxプレビューとは独立");

                ui.add_space(10.0);
                ui.separator();
                ui.heading("実行");

                let recording_busy = self.recording.is_some() || self.finalize_rx.is_some();
                let streaming_active = self.streaming.is_some();
                let target_ready = self.streaming_target.is_ready();

                if !recording_busy {
                    if ui.add_sized([SOURCE_SELECTOR_WIDTH, 34.0], egui::Button::new("● 録画開始")).clicked() {
                        self.start_recording();
                    }
                } else if self.recording.is_some() {
                    if ui.add_sized([SOURCE_SELECTOR_WIDTH, 38.0], egui::Button::new("■ 録画停止")).clicked() {
                        self.stop_recording();
                    }
                } else {
                    ui.add_enabled(false, egui::Button::new("MP4仕上げ中…"));
                }

                if !streaming_active {
                    if ui.add_enabled(target_ready, egui::Button::new("● 配信開始")).clicked() {
                        self.start_streaming();
                    }
                } else if ui.button("■ 配信停止").clicked() {
                    self.stop_streaming();
                }

                if !recording_busy && !streaming_active {
                    if ui.add_enabled(target_ready, egui::Button::new("● 録画＋配信")).clicked() {
                        self.start_recording();
                        self.start_streaming();
                    }
                }
                ui.small(&self.streaming_message);
                if let Some(streaming) = &self.streaming {
                    ui.small(format!("配信経過: {} 秒", streaming.elapsed_seconds()));
                }
                ui.small("Phase 9.3.4: 配信中もGain / Mute / 配信Mix / Masterをリアルタイム反映。音声デバイスやアプリ追加・削除は配信停止中に変更します。");
                ui.separator();
                ui.small(&self.font_message);
                    });
            });

        egui::CentralPanel::default().show(ctx, |ui| {
            let levels = self.audio.as_ref().map(|a| a.levels()).unwrap_or_default();
            let content_height = ui.available_height();

            ui.horizontal_top(|ui| {
                ui.allocate_ui_with_layout(
                    egui::vec2(310.0, content_height),
                    egui::Layout::top_down(egui::Align::Min),
                    |ui| {
                        egui::ScrollArea::vertical()
                            .id_salt("preview_source_scroll")
                            .auto_shrink([false, false])
                            .show(ui, |ui| {
                    ui.heading("プレビュー");
                    let [preview_w, preview_h] = normal_preview_size();
                    let (outer, _) = ui.allocate_exact_size(egui::vec2(preview_w, preview_h), egui::Sense::hover());
                    ui.painter().rect_filled(outer, 4.0, egui::Color32::from_rgb(18, 20, 24));

                    if let Some(texture) = &self.preview_texture {
                        let (draw_w, draw_h) = fit_aspect(
                            self.preview_size[0] as f32,
                            self.preview_size[1] as f32,
                            outer.width(),
                            outer.height(),
                        );
                        let image_rect = egui::Rect::from_center_size(outer.center(), egui::vec2(draw_w, draw_h));
                        ui.painter().image(
                            texture.id(),
                            image_rect,
                            egui::Rect::from_min_max(egui::Pos2::new(0.0, 0.0), egui::Pos2::new(1.0, 1.0)),
                            egui::Color32::WHITE,
                        );
                    } else {
                        ui.painter().text(
                            outer.center(),
                            egui::Align2::CENTER_CENTER,
                            "キャプチャ待機中…",
                            egui::FontId::proportional(16.0),
                            egui::Color32::LIGHT_GRAY,
                        );
                    }
                    ui.small(format!("表示 約300px / 入力 {}×{}", self.preview_size[0], self.preview_size[1]));

                    ui.add_space(10.0);
                    ui.separator();
                    self.capture_source_panel(ui);
                    ui.add_space(10.0);
                    ui.separator();
                    ui.heading("ワイプ / オーバーレイ");
                    ui.checkbox(&mut self.overlay_source.enabled, "跳ねるししゃも（テスト）を表示");
                    ui.horizontal(|ui| {
                        ui.label("位置 X");
                        ui.add(egui::Slider::new(&mut self.overlay_source.x_percent, 0.0..=100.0).suffix("%"));
                    });
                    ui.horizontal(|ui| {
                        ui.label("位置 Y");
                        ui.add(egui::Slider::new(&mut self.overlay_source.y_percent, 0.0..=100.0).suffix("%"));
                    });
                    ui.horizontal(|ui| {
                        ui.label("サイズ");
                        ui.add(egui::Slider::new(&mut self.overlay_source.width_percent, 5.0..=45.0).suffix("%"));
                    });
                    ui.checkbox(&mut self.overlay_source.bounce, "ぴょんぴょん動作");
                    ui.small("Phase 9.4.1: プレビューとライブ配信へ同じ合成結果を使用。外部画像/カメラ/クロマキーは次段階。");
                            });
                    },
                );

                ui.separator();

                ui.allocate_ui_with_layout(
                    egui::vec2(ui.available_width(), content_height),
                    egui::Layout::top_down(egui::Align::Min),
                    |ui| {
                        egui::ScrollArea::vertical()
                            .id_salt("audio_mixer_scroll")
                            .auto_shrink([false, false])
                            .show(ui, |ui| {
                    ui.heading("音声ミキサー");

                    if let Some(audio) = &self.audio {
                        let settings = audio.mixer_settings();
                        let status = audio.status();
                        let output_devices = audio.output_devices();
                        let input_devices = audio.input_devices();
                        let device_switch_enabled = self.recording.is_none()
                            && self.finalize_rx.is_none()
                            && self.streaming.is_none();

                        ui.columns(2, |columns| {
                            columns[0].group(|ui| {
                                ui.horizontal(|ui| {
                                    ui.label(format!("PC音声  {:>5.1} dB", dbfs(levels.desktop)));
                                    let mut muted = settings.desktop_muted;
                                    if ui.checkbox(&mut muted, "Mute").changed() {
                                        audio.set_desktop_muted(muted);
                                    }
                                });

                                let selected_output = audio.selected_output_device();
                                ui.add_enabled_ui(device_switch_enabled, |ui| {
                                    egui::ComboBox::from_id_salt("phase9_desktop_audio_device")
                                        .width(220.0)
                                        .selected_text(selection_label(&selected_output, &output_devices))
                                        .show_ui(ui, |ui| {
                                            if ui
                                                .selectable_label(
                                                    selected_output == AudioDeviceSelection::Default,
                                                    "Windows既定",
                                                )
                                                .clicked()
                                            {
                                                audio.set_output_device(AudioDeviceSelection::Default);
                                            }
                                            for device in &output_devices {
                                                let selection = AudioDeviceSelection::DeviceId(device.id.clone());
                                                if ui
                                                    .selectable_label(selected_output == selection, &device.name)
                                                    .clicked()
                                                {
                                                    audio.set_output_device(selection);
                                                }
                                            }
                                        });
                                });
                                ui.small(compact_source_name(&status.desktop, 30))
                                    .on_hover_text(&status.desktop);

                                paint_audio_meter(ui, levels.desktop);

                                let mut percent = settings.desktop_gain * 100.0;
                                ui.scope(|ui| {
                                    ui.spacing_mut().slider_width = 150.0;
                                    if ui
                                        .add(
                                            egui::Slider::new(&mut percent, 0.0..=100.0)
                                                .text("音量 %")
                                                .clamping(egui::SliderClamping::Always),
                                        )
                                        .changed()
                                    {
                                        audio.set_desktop_gain(percent / 100.0);
                                    }
                                });
                                if let Some(channel) = audio
                                    .audio_channels()
                                    .into_iter()
                                    .find(|channel| channel.id == ChannelMixerControl::DESKTOP_ID)
                                {
                                    ui.horizontal_wrapped(|ui| {
                                        let mut in_mix = channel.include_in_stream_mix;
                                        if ui.checkbox(&mut in_mix, "配信Mix").changed() {
                                            audio.set_channel_include_in_stream_mix(channel.id, in_mix);
                                        }
                                        let mut record = channel.record_individual;
                                        if ui.checkbox(&mut record, "個別WAV保存").changed() {
                                            audio.set_channel_record_individual(channel.id, record);
                                        }
                                    });
                                }
                            });

                            columns[1].group(|ui| {
                                ui.horizontal(|ui| {
                                    ui.label(format!("マイク  {:>5.1} dB", dbfs(levels.mic)));
                                    let mut muted = settings.mic_muted;
                                    if ui.checkbox(&mut muted, "Mute").changed() {
                                        audio.set_mic_muted(muted);
                                    }
                                });

                                let selected_input = audio.selected_input_device();
                                ui.add_enabled_ui(device_switch_enabled, |ui| {
                                    egui::ComboBox::from_id_salt("phase9_microphone_audio_device")
                                        .width(220.0)
                                        .selected_text(selection_label(&selected_input, &input_devices))
                                        .show_ui(ui, |ui| {
                                            if ui
                                                .selectable_label(
                                                    selected_input == AudioDeviceSelection::Default,
                                                    "Windows既定",
                                                )
                                                .clicked()
                                            {
                                                audio.set_input_device(AudioDeviceSelection::Default);
                                            }
                                            for device in &input_devices {
                                                let selection = AudioDeviceSelection::DeviceId(device.id.clone());
                                                if ui
                                                    .selectable_label(selected_input == selection, &device.name)
                                                    .clicked()
                                                {
                                                    audio.set_input_device(selection);
                                                }
                                            }
                                        });
                                });
                                ui.small(compact_source_name(&status.microphone, 30))
                                    .on_hover_text(&status.microphone);

                                paint_audio_meter(ui, levels.mic);

                                let mut percent = settings.mic_gain * 100.0;
                                ui.scope(|ui| {
                                    ui.spacing_mut().slider_width = 150.0;
                                    if ui
                                        .add(
                                            egui::Slider::new(&mut percent, 0.0..=100.0)
                                                .text("音量 %")
                                                .clamping(egui::SliderClamping::Always),
                                        )
                                        .changed()
                                    {
                                        audio.set_mic_gain(percent / 100.0);
                                    }
                                });
                                if let Some(channel) = audio
                                    .audio_channels()
                                    .into_iter()
                                    .find(|channel| channel.id == ChannelMixerControl::MICROPHONE_ID)
                                {
                                    ui.horizontal_wrapped(|ui| {
                                        let mut in_mix = channel.include_in_stream_mix;
                                        if ui.checkbox(&mut in_mix, "配信Mix").changed() {
                                            audio.set_channel_include_in_stream_mix(channel.id, in_mix);
                                        }
                                        let mut record = channel.record_individual;
                                        if ui.checkbox(&mut record, "個別WAV保存").changed() {
                                            audio.set_channel_record_individual(channel.id, record);
                                        }
                                    });
                                }
                            });
                        });

                        // Phase 9.2.4: process-loopback channels with individual WAV / Mix routing.
                        let application_channels: Vec<_> = audio
                            .audio_channels()
                            .into_iter()
                            .filter(|channel| channel.kind == AudioChannelKind::Application)
                            .collect();
                        let mut remove_channel = None;
                        for channel in application_channels {
                            ui.group(|ui| {
                                ui.horizontal(|ui| {
                                    ui.label(format!("{}  {:>5.1} dB", channel.name, dbfs(channel.current_level)));
                                    let mut muted = channel.muted;
                                    if ui.checkbox(&mut muted, "Mute").changed() {
                                        audio.set_channel_muted(channel.id, muted);
                                    }
                                    if ui.small_button("削除").clicked() {
                                        remove_channel = Some(channel.id);
                                    }
                                });
                                if let Some(pid) = channel.process_id {
                                    let state = if channel.enabled { "接続" } else { "切断" };
                                    ui.small(format!("アプリ音声 / PID {pid} / {state}"));
                                }
                                paint_audio_meter(ui, channel.current_level);
                                let mut percent = channel.gain * 100.0;
                                ui.scope(|ui| {
                                    ui.spacing_mut().slider_width = 170.0;
                                    if ui.add(
                                        egui::Slider::new(&mut percent, 0.0..=100.0)
                                            .text("音量 %")
                                            .clamping(egui::SliderClamping::Always),
                                    ).changed() {
                                        audio.set_channel_gain(channel.id, percent / 100.0);
                                    }
                                });
                                ui.horizontal(|ui| {
                                    let mut in_mix = channel.include_in_stream_mix;
                                    if ui.checkbox(&mut in_mix, "配信Mix").changed() {
                                        audio.set_channel_include_in_stream_mix(channel.id, in_mix);
                                    }
                                    let mut record = channel.record_individual;
                                    if ui.checkbox(&mut record, "個別WAV保存").changed() {
                                        audio.set_channel_record_individual(channel.id, record);
                                    }
                                });
                                ui.small("アプリ音声は独立キャプチャ中 / 録画時は原音WAVへ保存");
                            });
                        }
                        if let Some(id) = remove_channel {
                            audio.remove_audio_channel(id);
                        }

                        let app_sources = audio.application_sources();
                        let selected_app_label = self
                            .selected_application_audio_pid
                            .and_then(|pid| app_sources.iter().find(|source| source.capture_process_id == pid))
                            .map(application_source_label)
                            .unwrap_or_else(|| "アプリ音声を選択".to_owned());

                        ui.horizontal(|ui| {
                            egui::ComboBox::from_id_salt("phase9_application_audio_source")
                                .width(190.0)
                                .selected_text(compact_source_name(&selected_app_label, 28))
                                .show_ui(ui, |ui| {
                                    if app_sources.is_empty() {
                                        ui.label("音声を使用中のアプリがありません");
                                    }
                                    for source in &app_sources {
                                        let label = application_source_label(source);
                                        if ui
                                            .selectable_label(
                                                self.selected_application_audio_pid
                                                    == Some(source.capture_process_id),
                                                &label,
                                            )
                                            .on_hover_text(&label)
                                            .clicked()
                                        {
                                            self.selected_application_audio_pid =
                                                Some(source.capture_process_id);
                                        }
                                    }
                                });

                            let selected_source = self
                                .selected_application_audio_pid
                                .and_then(|pid| {
                                    app_sources
                                        .iter()
                                        .find(|source| source.capture_process_id == pid)
                                        .cloned()
                                });
                            if ui
                                .add_enabled(selected_source.is_some() && device_switch_enabled, egui::Button::new("＋追加"))
                                .clicked()
                            {
                                if let Some(source) = selected_source {
                                    match audio.add_application_channel(source) {
                                        Ok(_) => {
                                            self.application_audio_message =
                                                "アプリ音声チャンネルを追加しました".to_owned();
                                        }
                                        Err(err) => {
                                            self.application_audio_message =
                                                format!("アプリ音声追加失敗: {err}");
                                        }
                                    }
                                }
                            }
                        });

                        if ui.add_enabled(device_switch_enabled, egui::Button::new("アプリ音声一覧更新")).clicked() {
                            match audio.refresh_application_sources() {
                                Ok(()) => {
                                    self.application_audio_message =
                                        "アプリ音声一覧を更新しました".to_owned();
                                }
                                Err(err) => {
                                    self.application_audio_message =
                                        format!("アプリ音声一覧更新失敗: {err}");
                                }
                            }
                        }
                        ui.small(&self.application_audio_message);

                        ui.group(|ui| {
                            ui.label(format!("配信Mix {:>5.1} dB", dbfs(levels.mix)));
                            paint_audio_meter(ui, levels.mix);

                            let mut percent = settings.master_gain * 100.0;
                            ui.scope(|ui| {
                                ui.spacing_mut().slider_width = 170.0;
                                if ui
                                    .add(
                                        egui::Slider::new(&mut percent, 0.0..=100.0)
                                            .text("Master %")
                                            .clamping(egui::SliderClamping::Always),
                                    )
                                    .changed()
                                {
                                    audio.set_master_gain(percent / 100.0);
                                }
                            });
                        });

                        if ui
                            .add_enabled(device_switch_enabled, egui::Button::new("音声デバイス更新"))
                            .clicked()
                        {
                            match audio.refresh_devices() {
                                Ok(()) => { ui.small("デバイス一覧を更新しました"); }
                                Err(err) => { ui.small(format!("デバイス更新失敗: {err}")); }
                            }
                        }
                        if !device_switch_enabled {
                            ui.small(if self.streaming.is_some() {
                                "配信中は音声デバイスとアプリ構成を固定します"
                            } else {
                                "録画中は音声デバイスを固定します"
                            });
                        }

                        ui.small("個別WAVは原音のまま保存（Gain/Muteは非破壊）");
                        ui.small("配信Mix ONのチャンネルだけ完成MP4へ合流");
                        ui.small("個別WAV保存 OFFでもMix用の一時原音は録画後に自動削除");
                    } else {
                        ui.label("音声デバイスを取得できていません");
                    }

                    ui.small(&self.audio_message);
                            });
                    },
                );
            });
        });

        if self.vm.is_live {
            self.elapsed_ms = self.elapsed_ms.saturating_add(16);
        }

        let repaint_ms = if self.recording.is_some() {
            match self.recording_preview_mode {
                PreviewMode::Fps30 => 33,
                PreviewMode::Fps15 => 66,
                PreviewMode::Off => 250,
            }
        } else {
            16
        };
        ctx.request_repaint_after(std::time::Duration::from_millis(repaint_ms));
    }
}
