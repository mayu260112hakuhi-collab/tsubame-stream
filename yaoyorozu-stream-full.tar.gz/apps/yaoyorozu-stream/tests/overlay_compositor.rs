use yaoyorozu_stream::scene::OverlaySource;

#[test]
fn disabled_overlay_does_not_change_frame() {
    let overlay = OverlaySource::default();
    let mut rgba = vec![10u8; 64 * 36 * 4];
    let before = rgba.clone();
    overlay.compose_test_overlay(&mut rgba, 64, 36, 0.0);
    assert_eq!(rgba, before);
}

#[test]
fn enabled_overlay_changes_pixels_without_resizing_frame() {
    let mut overlay = OverlaySource::default();
    overlay.enabled = true;
    overlay.width_percent = 30.0;
    overlay.x_percent = 50.0;
    overlay.y_percent = 50.0;
    let mut rgba = vec![0u8; 160 * 90 * 4];
    let len = rgba.len();
    overlay.compose_test_overlay(&mut rgba, 160, 90, 0.25);
    assert_eq!(rgba.len(), len);
    assert!(rgba.iter().any(|&v| v != 0));
}
